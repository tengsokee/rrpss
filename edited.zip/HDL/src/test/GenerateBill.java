package test;


public class GenerateBill {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
